import numpy as np
from scipy.ndimage import distance_transform_edt
from skimage.measure import label
from glszm_props.glszm_props import get_glszm


def an_get_gldzm_props(rprop):
    in_img = rprop.intensity_image
    bw_img = rprop.image

    # Number of pixels
    Nv = np.float64(in_img.size)
    Ng = np.float64(np.max(in_img))
    glszm = get_glszm(in_img)

    Ns = np.float64(np.sum(glszm))

    # FOR IMAGE CHANGE THIS TO BW IMAGE!!
    # dist_mat = distance_transform_edt(np.pad(in_img, pad_width=(1,1), mode='constant', constant_values=0)>0)[1:-1,1:-1]
    dist_mat = distance_transform_edt(bw_img)
    Nd = np.int16(np.max(dist_mat))

    # print(Nd)
    # print(in_img)
    # print(glszm)
    # print(dist_mat)

    D = np.zeros((np.int(Ng), Nd))
    for int_lvl in range(0, np.max(in_img) + 1):
        bw = label(in_img == int_lvl, connectivity=1)

        for use_val in range(1, np.max(bw) + 1):
            dist_idx = np.int8(np.min(dist_mat[bw == use_val]))
            D[int_lvl - 1, dist_idx - 1] += 1

    # di = np.sum(D, axis=1)
    dj = np.float64(np.sum(D, axis=0))
    di = np.float64(np.sum(D, axis=1))
    j = np.float64(np.array(range(1, D.shape[1] + 1)))
    i = np.float64(np.array(range(1, D.shape[0] + 1)))

    # Small Distance Emphasis
    sde = np.sum(dj / j ** 2) / Ns

    # Large Distance Emphasis
    lde = np.sum(dj * (j ** 2)) / Ns

    # Low Grey Level Zone Emphasis
    lglze = np.sum(di / i ** 2) / Ns

    # High Grey Level Emphasis
    hglze = np.sum(di * (i ** 2)) / Ns

    # Small Distance Low Grey Level Zone Emphasis
    j = np.array(range(1, D.shape[1] + 1))
    i = np.array(range(1, D.shape[0] + 1))

    sdlgle = np.sum([D[ii - 1, jj - 1] / ((ii ** 2) * (jj ** 2)) for ii in i for jj in j]) / Ns

    # Small Distance High Grey Level Zone Emphasis
    sdhgle = np.sum([(D[ii - 1, jj - 1] * (ii ** 2)) / (jj ** 2) for ii in i for jj in j]) / Ns

    # Large Distance Low Grey Level Zone Emphasis
    ldlgle = np.sum([(D[ii - 1, jj - 1] * (jj ** 2)) / (ii ** 2) for ii in i for jj in j]) / Ns

    # Large Distance High Grey Level Zone Emphasis
    ldhgle = np.sum([D[ii - 1, jj - 1] * (ii ** 2) * (jj ** 2) for ii in i for jj in j]) / Ns

    # Grey Level Non Uniformity
    glnu = np.sum(di ** 2) / Ns

    # Grey Level Non Uniformity Normalised
    glnun = np.sum(di ** 2) / (Ns ** 2)

    # Zone Distance Non Uniformity
    zdnu = np.sum(dj ** 2) / Ns

    # Zone Distance Non Uniformity Normalised
    zdnun = np.sum(dj ** 2) / (Ns ** 2)

    # Zone Percentage
    zp = Ns / Nv

    # Grey Level Variance
    pij = D / Ns
    mui = np.sum([pij[ii - 1, jj - 1] * ii for ii in i for jj in j])
    glv = np.sum([pij[ii - 1, jj - 1] * ((ii - mui) ** 2) for ii in i for jj in j])

    # Zone Distance Variance
    muj = np.sum([pij[ii - 1, jj - 1] * jj for ii in i for jj in j])
    zdv = np.sum([pij[ii - 1, jj - 1] * ((j - muj) ** 2) for ii in i for jj in j])

    # Zone Distance Entropy
    zde = -np.sum(
        [pij[ii - 1, jj - 1] * (np.log2(pij[ii - 1, jj - 1])) for ii in i for jj in j if pij[ii - 1, jj - 1] > 0])

    out_props = [
        sde,
        lde,
        lglze,
        hglze,
        sdlgle,
        sdhgle,
        ldlgle,
        ldhgle,
        glnu,
        glnun,
        zdnu,
        zdnun,
        zp,
        glv,
        zdv,
        zde
    ]

    out_lbl = [
        'SmallDistEmphasis',
        'LargeDistEmphasis',
        'LowGreyLevelZoneEmphasis',
        'HighGreyLevelZoneEmphasis',
        'SmallDistanceLowGreyLevelEmphasis',
        'SmallDistanceHighGreyLevelEmphasis',
        'LargeDistanceLowGreyLevelEmphasis',
        'LargeDistanceHighGreyLevelEmphasis',
        'GreyLevelNonUniformity',
        'GreyLevelNonUniformityNormalised',
        'ZoneDistanceNonUniformity',
        'ZoneDistanceNonUniformityNormalised',
        'ZonePercentage',
        'GreyLevelVariance',
        'ZoneDistanceVariance',
        'ZoneDistanceEntropy'
    ]
    out_lbl = ['GLDZM' + a for a in out_lbl]
    return out_props, out_lbl
