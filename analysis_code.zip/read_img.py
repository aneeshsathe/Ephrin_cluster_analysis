#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  9 14:59:01 2017

@author: aneesh
"""
# %% Import
import glob
import os
from skimage.io import imread, imshow, imsave
from skimage.measure import regionprops
from skimage import img_as_uint, img_as_ubyte
import cv2
import numpy as np
import pandas as pd
import collections
import multiprocessing
import warnings 
import scipy
import mahotas
from skimage.exposure import histogram
import warnings

from morp_hist_feats.morph_feats import an_morph_feats
from morp_hist_feats.intensity_feats import an_intensity_feats
from glcm_feats.glcm_feats import an_get_glcm_props
from glrlm_feats.glrlm_feats import an_get_glrlm_props
from ngtdm_feats.ngtdm_feats import an_get_ngtdm_props
from glszm_props.glszm_props import an_get_glszm_props
from gldzm_props.gldzm_props import an_get_gldzm_props
from ngldm_props.ngldm_props import an_ngldm_props
from base_feats.base_feats import  an_base_feats

# %% Functions


def an_getFilePairs(root_root, im_pat, bf_pat, lblList):
    # Get File lists for mask and images
    imFileList = glob.glob(os.path.join(root_root, '*/', im_pat))
    bfFileList = glob.glob(os.path.join(root_root, '*/', bf_pat))

    # Match base names, extract label and create matched file-label list
    filePairs = []
    for imfile in imFileList:
        filePairs.append([
                imfile,
                [bffile for bffile in bfFileList if imfile[:-len(im_pat)+1] in bffile][0],
                [l for l in lblList if l in imfile][0]
            ])
    return(filePairs)


def an_norm_img(in_img):
    out = np.zeros(in_img.shape, np.double)
    norm_im = cv2.normalize(in_img, out, 1.0, 0.0, cv2.NORM_MINMAX, dtype=cv2.CV_64F)
    return norm_im


def an_df_filler(in_f, row_num, in_dat, col_name):
    for count, a in enumerate(in_dat):
        if len(col_name) > 1:
            in_f.loc[row_num, col_name[count] + str(count + 1)] = a
        else:
            in_f.loc[row_num, col_name[0] + str(count + 1)] = a

    return in_f


def an_get_props(rprop):
    out_props0, out_lbl0 = an_base_feats(rprop)

    out_props1, out_lbl1 = an_morph_feats(rprop)

    out_props2, out_lbl2 = an_intensity_feats(rprop)

    # out_props3, out_lbl3 = an_get_glcm_props(rprop, sum_glcm=False, mean_props=True, all_glcm_props=False)

    out_props4, out_lbl4 = an_get_glrlm_props(rprop)
    #
    # out_props5, out_lbl5 = an_get_ngtdm_props(rprop)
    #
    # out_props6, out_lbl6 = an_get_glszm_props(rprop)
    #
    # out_props7, out_lbl7 = an_get_gldzm_props(rprop)
    #
    # out_props8, out_lbl8 = an_ngldm_props(rprop)

    # final_lbl = np.hstack((out_lbl1, out_lbl2, out_lbl3, out_lbl4, out_lbl5, out_lbl6, out_lbl7, out_lbl8))
    # final_props = np.hstack(
    #     (out_props1, out_props2, out_props3, out_props4, out_props5, out_props6, out_props7, out_props8))
    final_lbl = np.hstack((out_lbl0, out_lbl1, out_lbl2, out_lbl4#,
                           # out_lbl3, out_lbl5, out_lbl6, out_lbl7, out_lbl8
                           ))
    final_props = np.hstack((out_props0, out_props1, out_props2, out_props4#,
                             # out_props3, out_props5, out_props6, out_props7, out_props8
                             ))

    return final_props, final_lbl


def an_write_data(file_name, in_props, col_names, sav_lbl, file_nm, count, pool_num):
    file_exists_check = os.path.isfile(file_name)  # os.path.exists(os.path.dirname(file_name))
    if not os.path.exists(os.path.dirname(file_name)):  # file_exists_check:
        os.makedirs(os.path.dirname(file_name))
    with open(file_name, 'a') as cf:
        feat_frame = pd.DataFrame([])
        feat_frame.loc[0, 'CellType'] = sav_lbl
        feat_frame.loc[0, 'ImageName'] = file_nm

        feat_frame = an_df_filler(feat_frame, 0, in_props, col_names)
        if not file_exists_check: # count == 0 & pool_num==0:
            feat_frame.to_csv(cf, header=True, index=False)
        else:
            feat_frame.to_csv(cf, header=False, index=False)

    return


def an_sav_im(img_write_path, in_img, in_lbl, file_nm):
    fold_path = os.path.join(img_write_path, in_lbl)
    if not os.path.exists(fold_path):
        os.makedirs(fold_path)
    file_name = os.path.join(fold_path, file_nm)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
    imsave(file_name, img_as_uint(in_img))
    return


def an_get_img_prop(filePairs, im_pat, pool_num=0, img_write_path=None, csv_write_path=None):
    # pool_num = 1
    im_count = 1

    for im_num, flps in enumerate(filePairs):
        print('Image ' + str(im_num) + ' of ' + str(len(filePairs)) + ' Proc num: ' + str(pool_num))
        inImg = imread(flps[0])
        lblImg = imread(flps[1])
        sav_lbl = flps[2]
    
        for prop_nb, region_prop in enumerate(regionprops(lblImg, inImg)):

            minr, minc, maxr, maxc = region_prop.bbox
            crop_im = inImg[minr:maxr, minc:maxc].copy()
            region_lbl_img = lblImg[minr:maxr, minc:maxc] * region_prop.image
            bg_zero_im = crop_im * region_prop.image
            # norm_im = an_norm_img(bg_zero_im)
            #bg_zero_im = img_as_ubyte(bg_zero_im)


            for rprop in regionprops(region_lbl_img, bg_zero_im):

                bg_zero_props, bg_col_names = an_get_props(rprop)
                csv_full_path = csv_write_path+str(pool_num)+'_bg_zero_'+sav_lbl+csv_write_name

                file_nm = os.path.split(flps[0])[1][:-len(im_pat) + 1] + \
                                       '_' + str(im_num).zfill(3) + \
                                       '_p' + str(pool_num) + \
                                       '_rg' + str(prop_nb) + \
                                       '_' + str(im_count).zfill(4) + \
                                       '_bg_zero.png'
                an_write_data(csv_full_path, bg_zero_props, bg_col_names, sav_lbl, file_nm, prop_nb, pool_num)
                #an_sav_im(img_write_path, bg_zero_im, sav_lbl+'/', file_nm)

                # norm_props, norm_col_names = an_get_props(region_lbl_img, norm_im)
                # csv_full_path = csv_write_path+str(pool_num)+'_norm_'+sav_lbl+csv_write_name
                #
                # file_nm = os.path.split(flps[0])[1][:-len(im_pat) + 1] + \
                #                        '_' + str(im_num).zfill(3) + \
                #                        '_p' + str(pool_num) + \
                #                        '_rg' + str(prop_nb) + \
                #                        '_' + str(im_count).zfill(4) + \
                #                        '_norm.png'
                # an_write_data(csv_full_path, norm_props, norm_col_names, sav_lbl, file_nm, prop_nb, pool_num)
                # an_sav_im(img_write_path, norm_im, sav_lbl+'/norm/', file_nm)
                im_count += 1
    
    return 0


# %%

root_root = '/media/data/Andrea/Images/'
img_write_path = '/media/data/Andrea/results/Analysis_20170321/imgs/'

bf_pat = '*_OT.TIF'
im_pat = '*_w1TRITC.TIF'
#lblList = ['HeyA8', 'MCF7']
lblList = ['A549', 'MCF7', 'MDAMB231', 'HeyA8',
           'MCF10A', 'PEO1', 'OVCAwt', 'MNK28', 'SKOV3']

csv_write_path = '/media/data/Andrea/results/Analysis_20170321/csv/'
csv_write_name = '_out_props_test.csv'



# %%
def chunk_it(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg

    return out


def an_gen_chunks(filePairs, chunk_num, csv_write_path):
    img_idxs = chunk_it(range(len(filePairs)), chunk_num)
    out_img_chunks = [([filePairs[x] for x in idx], idx[0], i, csv_write_path) for i, idx in enumerate(img_idxs)]
    return out_img_chunks


def multi_run_wrapper(args):
    return get_results(*args)


def get_results(filePairs, img_idx, pool_num, csv_write_path):
    an_get_img_prop(filePairs, im_pat, pool_num, img_write_path, csv_write_path)
    #an_get_img_prop(filePairs, im_pat, pool_num, img_write_path)
    #    out_data_df = an_get_img_prop(filePairs, im_pat, pool_num, img_write_path)
    return 0  # out_data_df


filePairs = an_getFilePairs(root_root, im_pat, bf_pat, lblList)#[0:10]

chunk_num = 10
# with multiprocessing.Pool(chunk_num) as pool:
pool = multiprocessing.Pool(chunk_num)
pool.map(multi_run_wrapper, an_gen_chunks(filePairs, chunk_num, csv_write_path))
# all_data_df = zip(pool.map(multi_run_wrapper, an_gen_chunks(filePairs, chunk_num)))

# %% Write Data

for lb in lblList:
    fl_list = glob.glob(csv_write_path+'*_bg_zero_'+lb+'_out_props_test.csv')
    header_saved = False
    if fl_list:
        with open(csv_write_path+lb+'_bg_zero_props.csv', 'wb') as fout:
            for filename in fl_list:
                with open(filename) as fin:
                    header = next(fin)
                    if not header_saved:
                        fout.write(header)
                        header_saved = True
                    for line in fin:
                        fout.write(line)
                os.remove(filename)

#%%
# for lb in lblList:
#     fl_list = glob.glob(csv_write_path+'*_norm_'+lb+'_out_props_test.csv')
#     header_saved = False
#     if fl_list:
#         with open(csv_write_path+lb+'_norm_props.csv','wb') as fout:
#             for filename in fl_list:
#                 with open(filename) as fin:
#                     header = next(fin)
#                     if not header_saved:
#                         fout.write(header)
#                         header_saved = True
#                     for line in fin:
#                         fout.write(line)
#                 os.remove(filename)
#%%
#flps = filePairs[0]
#inImg = imread(flps[0])
#lblImg = imread(flps[1])
#sav_lbl = flps[2]
#for prop_nb, region_prop in enumerate(regionprops(lblImg, inImg)):
#
#    minr, minc, maxr, maxc = region_prop.bbox
#    crop_im = inImg[minr:maxr, minc:maxc].copy()
#    #region_lbl_img = lblImg[minr:maxr, minc:maxc] * region_prop.image
#    bg_zero_im = crop_im * region_prop.image
#    norm_im = an_norm_img(bg_zero_im)
#
#   # bg_zero_props, bg_col_names = an_get_props(region_lbl_img, bg_zero_im)
#    lbl_im = lblImg[minr:maxr, minc:maxc] * region_prop.image
#               
##def an_get_props(lbl_im, crop_im):
#    region_prop = regionprops(lbl_im, crop_im)[0]
#    pixel_size = 0.016; # micrometer per pixel
#
#    use_area = region_prop.area
#    area_um = use_area*pixel_size
#    
#    int_vec = region_prop.intensity_image[region_prop.image]
#    
#    sum_int = sum(int_vec)
#    mean_int = sum_int/use_area
#    min_int = min(int_vec)
#    max_int = max(int_vec)
#    stdev_int = np.std(int_vec)
#    coeffvar_int = stdev_int/mean_int
#    stdev_int_per_area = stdev_int/area_um
#    coeffvar_int_per_area = coeffvar_int/area_um
#    
#    entropy_orig = -scipy.stats.entropy(int_vec)
#    entropy_per_pixel = entropy_orig/use_area       # s_new per pixel
#    
#    p1 = int_vec/np.float(mean_int)
#    p = p1[p1 > 0]
#    entropy_new = sum(p*np.log(p)) # useless. Sensitive to illumination variations of different data, s is scaled by average intensity.
#    
#    
#    # Same as scipy entropy so ignored
#    # p_new1 = int_vec/float(sum_int)
#    # p_new = p_new1[p_new1>0]
#    # s_new = sum(p_new*np.log(p_new))
#    
#    
#    entropy_new_perum = entropy_new/area_um  # useless
#                                                                                                                                
#    entropy_new_by_sumInt = entropy_new/sum_int  # Not that sensitive to illumination variations of different data.
#    
#    # Entropy using histogram
#    pro_bin_prob, bin_cen = histogram(crop_im[region_prop.image])
#    
#    bin_prob = np.float16(pro_bin_prob) / sum(pro_bin_prob)
#    bin_prob = bin_prob[bin_prob>0]
#    entropy_hist = sum(bin_prob * np.log2(bin_prob))  # entropy
#    entropy_hist_perum = entropy_hist/area_um                                                                                                                              
#    entropy_hist_by_sumInt = entropy_hist/sum_int 
#    uniformity_hist = sum(np.square(bin_prob))  # Uniformity
#    
#    out_kurtosis = scipy.stats.kurtosis(int_vec)
#    out_skew = scipy.stats.skew(int_vec)
#    out_smoothness = 1.0 - (1.0 / (1.0 + np.square(np.std(int_vec))))
#    
#    out_roundness = mahotas.features.roundness(region_prop.image)
#                           
#    out_props = [
#            stdev_int,
#            stdev_int_per_area,
#            coeffvar_int,
#            coeffvar_int_per_area,
#            entropy_orig,
#            entropy_per_pixel,
#            entropy_new,
#            entropy_new_perum,
#            entropy_new_by_sumInt,
#            entropy_hist,
#            entropy_hist_perum,
#            entropy_hist_by_sumInt,
#            uniformity_hist,
#            out_kurtosis,
#            out_skew,
#            out_smoothness,
#            sum_int,
#            mean_int,
#            min_int,
#            max_int,
#            region_prop.area,
#            region_prop.eccentricity,
#            region_prop.euler_number,
#            region_prop.equivalent_diameter,
#            region_prop.extent, 
#            region_prop.major_axis_length,
#            region_prop.minor_axis_length,
#            region_prop.orientation, 
#            region_prop.perimeter,
#            region_prop.solidity, 
#            out_roundness
#            ]
#    out_lbl = [        
#            'Stdev',
#            'StdevPerum',
#            'CoeffVar',
#            'CoeffVarPerum',
#            'Entropy',
#            'EntropyPerPix',
#            'EntropyNew',
#            'EntropyNewPerum',
#            'EntropyNewBySumInt',
#            'EntropyHist',
#            'EntropyHistPerum',
#            'EntropyHistBySumInt',
#            'UniformityHist',
#            'Kurtosis',
#            'Skewness',
#            'Smoothness',
#            'SumInt',
#            'MeanInt',
#            'MinInt',
#            'MaxInt',
#            'Area',
#            'Eccentricity',
#            'Euler_Num',
#            'Equi_Diam',
#            'Extent', 
#            'Maj_ax_len',
#            'Min_ax_len',
#            'Orientation', 
#            'Perimeter',
#            'Solidity', 
#            'Roundness'
#            ]
#    
#   # return out_props, out_lbl
#
##bg_zero_props, bg_col_names = an_get_props(lbl_im, bg_zero_im)
#print(out_props)
#print(len(out_props))
#print(len(out_lbl))
##%%
#feat_frame = pd.DataFrame([])
#feat_frame.loc[0, 'CellType'] = sav_lbl
#feat_frame.loc[0, 'ImageName'] = 'test'#file_nm
#
##an_df_filler(feat_frame, 0, out_props, out_lbl)
#
##%%
## Entropy using histogram
#pro_bin_prob, bin_cen = histogram(norm_im[region_prop.image])
#
#bin_prob = np.float16(pro_bin_prob) / sum(pro_bin_prob)
#bin_prob = bin_prob[bin_prob>0]
#Entropy_hist = sum(bin_prob * np.log2(bin_prob)),  # entropy
#Uniformity_hist = sum(np.square(bin_prob)),  # Uniformity
#
#out_props = [region_prop.mean_intensity,  # mean intensity
#             1.0 - (1.0 / (1.0 + np.square(np.std(region_prop.intensity_image)))),  # smoothness
#             np.std(crop_im[region_prop.image]),  # std
#             sum(bin_prob * np.log2(bin_prob)),  # entropy
#             sum(np.square(bin_prob)),  # Uniformity
#             scipy.stats.skew(np.ndarray.flatten(crop_im[region_prop.image])),  # skewness
#             ]
#out_lbl = ['Mean_int', 'Smoothness', 'StDev', 'Entropy', 'Uniformity', 'Skewness']
## %%
#
#print(entropy_orig)
#print(entropy_new)
#print(sum(bin_prob * np.log2(bin_prob)))
# %% TRASH

#def an_get_props(lbl_im, crop_im):
#    region_prop = regionprops(lbl_im, crop_im)[0]
#    out_props = [region_prop.area, region_prop.eccentricity,
#                 region_prop.euler_number, region_prop.equivalent_diameter,
#                 region_prop.extent, region_prop.major_axis_length,
#                 region_prop.minor_axis_length, region_prop.max_intensity,
#                 region_prop.mean_intensity, region_prop.min_intensity,
#                 region_prop.orientation, region_prop.perimeter,
#                 region_prop.solidity, mahotas.features.roundness(region_prop.image),
#                 scipy.stats.kurtosis(crop_im.flatten()), scipy.stats.skew(crop_im.flatten())
#                 ]
#    out_lbl = ['Area', 'Eccentricity',
#               'Euler_Num', 'Equi_Diam',
#               'Extent', 'Maj_ax_len',
#               'Min_ax_len', 'Max_int',
#               'Mean_int', 'Min_int',
#               'Orientation', 'Perimeter',
#               'Solidity', 'Roundness',
#               'Kurtosis', 'Skewness']
#
#    return out_props, out_lbl






















