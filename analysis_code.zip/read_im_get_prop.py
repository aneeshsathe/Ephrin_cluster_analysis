import glob
import pandas as pd
import multiprocessing
#import warnings
import os
from img_prop_extraction.an_img_prop import an_get_img_prop



root_root = '/media/data/Andrea/Images/'
img_write_path = '/media/data/Andrea/results/imgs/'
csv_write_path = '/media/data/Andrea/results/'
bf_pat = '*_OT.TIF'
im_pat = '*_w1TRITC.TIF'
lblList = ['A549', 'MCF7', 'MDAMB231', 'HeyA8', 'MCF10A', 'PEO1', 'OVCAwt', 'MNK28', 'SKOV3']


def an_getFilePairs(root_root, im_pat, bf_pat, lblList):
    # Get File lists for mask and images
    imFileList = glob.glob(os.path.join(root_root, '*/', im_pat))
    bfFileList = glob.glob(os.path.join(root_root, '*/', bf_pat))

    # Match base names, extract label and create matched file-label list
    filePairs = []
    for imfile in imFileList:
        filePairs.append([
                imfile,
                [bffile for bffile in bfFileList if imfile[:-len(im_pat)+1] in bffile][0],
                [l for l in lblList if l in imfile][0]
            ])
    return(filePairs)


def chunk_it(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg

    return out


def an_gen_chunks(filePairs, chunk_num):
    img_idxs = chunk_it(range(len(filePairs)), chunk_num)
    out_img_chunks = [([filePairs[x] for x in idx], idx, i) for i, idx in enumerate(img_idxs)]
    return out_img_chunks


def multi_run_wrapper(args):
    return get_results(*args)  


def get_results(filePairs, img_idx, pool_num):  
    out_data_df = an_get_img_prop(filePairs, im_pat, pool_num, img_write_path)
    return out_data_df


filePairs = an_getFilePairs(root_root, im_pat, bf_pat, lblList)

chunk_num = 10
pool = multiprocessing.Pool(chunk_num)

all_data_df = zip(pool.map(multi_run_wrapper, an_gen_chunks(filePairs, chunk_num)))

out = [all_data_df[frame][0] for frame in range(len(all_data_df))]

out_data = pd.concat(out, axis=0, join='inner')

out_data.to_csv(csv_write_path + 'results_out_props.csv', index=False)
print('Results Written!')
pool.close()
