

import numpy as np
import scipy

def an_intensity_feats(rprop):

    int_vec = rprop.intensity_image[rprop.image]
    Nv = len(int_vec)

    sum_int = sum(int_vec)
    mean_int = rprop.mean_intensity
    min_int = rprop.min_intensity
    max_int = rprop.max_intensity
    range_int = max_int - min_int
    median_int = np.median(int_vec)
    P10, P90, P75, P25 = np.percentile(int_vec, [10, 90, 75, 25])
    iqt_range = P75 - P25
    mean_abs_dev = np.sum(np.abs(int_vec - rprop.mean_intensity)) / Nv

    int_vec1090 = int_vec[(int_vec > P10) & (int_vec < P90)]

    if int_vec1090.size:        #int_vec1090
        robust_mean_abs_dev = np.sum(np.abs(int_vec1090 - np.mean(int_vec1090))) / len(int_vec1090)
        #print('here')

    else:
        robust_mean_abs_dev = 0
        #print('here2')

    med_abs_dev = np.sum(np.abs(int_vec - median_int)) / Nv
    stdev_int = np.std(int_vec)
    coeffvar_int = stdev_int / mean_int
    quart_coeff_dispersion = (P75 + P25) / (P75 + P25)
    energy_int = sum(int_vec ** 2)
    rms_int = np.sqrt(energy_int / Nv)

    entropy_orig = scipy.stats.entropy(int_vec)

    out_props = [
        sum_int,
        mean_int,
        min_int,
        max_int,
        range_int,
        median_int,
        P10,
        P90,
        iqt_range,
        mean_abs_dev,
        robust_mean_abs_dev,
        med_abs_dev,
        stdev_int,
        coeffvar_int,
        quart_coeff_dispersion,
        energy_int,
        rms_int,
        entropy_orig
    ]

    out_lbl = [
        'SumInt',
        'MeanInt',
        'MinInt',
        'MaxInt',
        'RangeInt',
        'MedianInt',
        'Percentile10',
        'Percentile90',
        'IQtR',
        'MeanAbsDev',
        'RobustMeanAbsDev',
        'MedianAbsDev',
        'Stdev',
        'CoeffVar',
        'QuartCoeffDispersion',
        'EnergyInt',
        'RMSInt',
        'EntropyInt'
    ]
    out_lbl = ['Int' + a for a in out_lbl]
    return np.array(out_props), out_lbl