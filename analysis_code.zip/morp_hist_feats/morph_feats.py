

import numpy as np
import math
import skimage
from sklearn.metrics.pairwise import euclidean_distances, manhattan_distances
from skimage.transform import rescale

def an_morph_feats(rprop):
    out_compactness = rprop.area / (rprop.perimeter) ** 2
    aspect_ratio = rprop.minor_axis_length / rprop.major_axis_length
    out_roundness = 4 * (rprop.area / (np.pi * (rprop.major_axis_length ** 2)))
    cen_mass_shift = np.linalg.norm(np.array(rprop.local_centroid) - np.array(rprop.weighted_local_centroid), ord=2)

    # moran_i, geary_c = an_moran_geary_meas(rprop)

    out_props = [
        rprop.area,
        rprop.perimeter,
        out_compactness,
        aspect_ratio,
        rprop.solidity,
        out_roundness,
        rprop.eccentricity,
        cen_mass_shift,
        #moran_i,
        #geary_c,
    ]

    out_lbl = [
        'Area',
        'Perimeter',
        'Compactness',
        'AspectRatio',
        'Solidity',
        'Roundness',
        'Eccentricity',
        'CenterOfMassShift',
        #'MoransI',
        #'GearysC'
    ]
    out_lbl = ['Morph'+a for a in out_lbl]
    return np.array(out_props), out_lbl




# def an_moran_geary_meas(rprop):
#     i_img = rescale(rprop.intensity_image, 0.5)
#     bw_img = rescale(rprop.image, 0.5) > 0
#     int_vec = i_img[bw_img]
#     # int_vec = rprop.intensity_image[rprop.image]
#     Nv = len(int_vec)
#     mean_int = rprop.mean_intensity
#
#     # c_x, c_y = np.where(rprop.image)
#     c_x, c_y = np.where(bw_img)
#     points_list = np.column_stack((c_x, c_y))
#     # print(len(points_list))
#
#     int_vec_sub = int_vec - mean_int
#     denom = sum(int_vec_sub ** 2)
#
#     # MORANS I
#     a = euclidean_distances(points_list)
#
#     b = np.outer(int_vec_sub.T, int_vec_sub)
#
#     a_1 = 1 / a[a != 0]
#     wt = np.sum(a_1)
#     moran_nume = np.sum(b[a != 0] * a_1)
#     moran_i = (Nv / wt) * (moran_nume / denom)
#
#     c = ((int_vec_sub[:, np.newaxis] - int_vec_sub) ** 2)
#     geary_nume = np.sum(c[a != 0] * a_1)
#     geary_c = ((Nv - 1) / (2 * wt)) * (geary_nume / denom)
#
#     return moran_i, geary_c


def an_moran_geary_meas(rprop):
    i_img = rescale(rprop.intensity_image, 0.5)
    bw_img = rescale(rprop.image, 0.5) > 0
    int_vec = i_img[bw_img]
    # int_vec = rprop.intensity_image[rprop.image]
    Nv = len(int_vec)
    mean_int = rprop.mean_intensity

    # c_x, c_y = np.where(rprop.image)
    c_x, c_y = np.where(bw_img)
    # i_img = skimage.img_as_ubyte(rprop.intensity_image)
    # int_vec = i_img[rprop.image]
    # Nv = len(int_vec)
    # mean_int = rprop.mean_intensity
    #
    # c_x, c_y = np.where(rprop.image)
    points_list = np.column_stack((c_x, c_y))

    int_vec_sub = int_vec - mean_int
    denom = sum(int_vec_sub ** 2)

    wt = 0
    moran_nume = 0
    geary_nume = 0

    for i in range(Nv):
        for j in range(Nv):
            if i != j:
                wtij = 1 / (math.hypot(points_list[j][0] - points_list[i][0], points_list[j][1] - points_list[i][1]))
                wt += wtij
                moran_nume += wtij * int_vec_sub[i] * int_vec_sub[j]
                geary_nume += wtij * ((int_vec_sub[i] - int_vec_sub[j]) ** 2)

    moran_i = (Nv / wt) * (moran_nume / denom)
    geary_c = ((Nv - 1) / (2 * wt)) * (geary_nume / denom)

    return moran_i, geary_c