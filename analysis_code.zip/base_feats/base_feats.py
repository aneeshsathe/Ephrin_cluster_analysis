import numpy as np
import scipy
import mahotas
from skimage.exposure import histogram


def an_base_feats(region_prop):
    # region_prop = regionprops(lbl_im, crop_im)[0]
    pixel_size = 0.016  # micrometer per pixel

    use_area = region_prop.area
    area_um = use_area*pixel_size

    #int_vec = region_prop.intensity_image[region_prop.image]
    int_vec = region_prop.intensity_image[region_prop.image]


    sum_int = sum(int_vec)
    mean_int = sum_int/use_area
    min_int = min(int_vec)
    max_int = max(int_vec)
    stdev_int = np.std(int_vec)
    stdev_byIntRange = stdev_int/(np.max(int_vec)-np.min(int_vec))
    coeffvar_int = stdev_int/mean_int
    coeffvar_byIntRange = coeffvar_int/(np.max(int_vec)-np.min(int_vec))
    stdev_int_per_area = stdev_int/area_um
    coeffvar_int_per_area = coeffvar_int/area_um

    entropy_orig = -scipy.stats.entropy(int_vec)
    entropy_per_pixel = entropy_orig/use_area       # s_new per pixel

    p1 = int_vec/np.float(mean_int)
    p = p1[p1 > 0]
    entropy_new = sum(p*np.log(p)) # useless. Sensitive to illumination variations of different data, s is scaled by average intensity.

    # Same as scipy entropy so ignored
    # p_new1 = int_vec/float(sum_int)
    # p_new = p_new1[p_new1>0]
    # s_new = sum(p_new*np.log(p_new))

    entropy_new_perum = entropy_new/area_um  # useless

    entropy_new_by_sumInt = entropy_new/sum_int  # Not that sensitive to illumination variations of different data.

    # Entropy using histogram
    pro_bin_prob, bin_cen = histogram(region_prop.intensity_image[region_prop.image])

    bin_prob = np.float16(pro_bin_prob) / sum(pro_bin_prob)
    bin_prob = bin_prob[bin_prob > 0]
    entropy_hist = sum(bin_prob * np.log2(bin_prob))  # entropy
    entropy_hist_perum = entropy_hist/area_um
    entropy_hist_by_sumInt = entropy_hist/sum_int
    uniformity_hist = sum(np.square(bin_prob))  # Uniformity

    out_kurtosis = scipy.stats.kurtosis(int_vec)
    out_skew = scipy.stats.skew(int_vec)
    out_smoothness = 1.0 - (1.0 / (1.0 + np.square(np.std(int_vec))))

    out_roundness = mahotas.features.roundness(region_prop.image)

    out_props = [
            stdev_int,
            stdev_byIntRange,
            coeffvar_int,
            coeffvar_byIntRange,
            stdev_int_per_area,
            coeffvar_int_per_area,
            entropy_orig,
            entropy_per_pixel,
            entropy_new,
            entropy_new_perum,
            entropy_new_by_sumInt,
            entropy_hist,
            entropy_hist_perum,
            entropy_hist_by_sumInt,
            uniformity_hist,
            out_kurtosis,
            out_skew,
            out_smoothness,
            sum_int,
            mean_int,
            min_int,
            max_int,
            region_prop.area,
            region_prop.eccentricity,
            region_prop.euler_number,
            region_prop.equivalent_diameter,
            region_prop.extent,
            region_prop.major_axis_length,
            region_prop.minor_axis_length,
            region_prop.orientation,
            region_prop.perimeter,
            region_prop.solidity,
            out_roundness,
            ]

    out_lbl = [
            'Stdev',
            'StdevByIntRange',
            'CoeffVar',
            'CoeffVarByIntRange',
            'StdevPerum',
            'CoeffVarPerum',
            'Entropy',
            'EntropyPerPix',
            'EntropyNew',
            'EntropyNewPerum',
            'EntropyNewBySumInt',
            'EntropyHist',
            'EntropyHistPerum',
            'EntropyHistBySumInt',
            'UniformityHist',
            'Kurtosis',
            'Skewness',
            'Smoothness',
            'SumInt',
            'MeanInt',
            'MinInt',
            'MaxInt',
            'Area',
            'Eccentricity',
            'Euler_Num',
            'Equi_Diam',
            'Extent',
            'Maj_ax_len',
            'Min_ax_len',
            'Orientation',
            'Perimeter',
            'Solidity',
            'Roundness',
            ]
    return out_props, out_lbl