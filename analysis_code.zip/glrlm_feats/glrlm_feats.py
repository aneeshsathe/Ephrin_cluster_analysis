import itertools
import numpy as np


def an_get_glrlm_props(rprop):
    in_img = rprop.intensity_image
    glr0, glr45, glr90, glr135 = get_glrlms(in_img)
    grlm_props_list = [get_glrlm_props(in_glr) for in_glr in [glr0, glr45, glr90, glr135]]
    glrm_props = np.mean(grlm_props_list, axis=0)
    glrm_lbl = get_glrlm_lbl()
    glrm_lbl = ['GLRLM' + a for a in glrm_lbl]
    return glrm_props, glrm_lbl


def get_glrlm_props(in_glr):
    Ns = np.float64(np.sum(in_glr))
    Nv = np.size(in_glr)
    ri = np.float64(np.sum(in_glr, axis=0))
    rj = np.float64(np.sum(in_glr, axis=1))

    j = np.float64(np.array([i for i in range(1, len(ri) + 1)]))
    i = np.float64(np.array([i for i in range(1, len(rj) + 1)]))

    pij = in_glr / Ns
    mui = np.sum([pij[i - 1, j - 1] * i for i in range(1, pij.shape[0] + 1) for j in range(1, pij.shape[1] + 1)])
    muj = np.sum([pij[i - 1, j - 1] * j for i in range(1, pij.shape[0] + 1) for j in range(1, pij.shape[1] + 1)])

    # Short Run Emphasis
    sre = np.sum(rj / (j ** 2)) / Ns

    # Long Run Emphasis
    lre = np.sum(rj * (j ** 2)) / Ns

    # Low Grey Level Emphasis
    lgle = np.sum(ri / (i ** 2)) / Ns

    # High Grey Level Emphasis
    hgle = np.sum(ri * (i ** 2)) / Ns

    # Short Run Low Grey Level Emphasis
    srlgle = np.sum([in_glr[i - 1, j - 1] / ((i ** 2) * (j ** 2)) for i in range(1, in_glr.shape[0] + 1) for j in
                     range(1, in_glr.shape[1] + 1)]) / Ns

    # Short Run High Grey Level Emphasis
    srhgle = np.sum([(in_glr[i - 1, j - 1] * (i ** 2)) / (j ** 2) for i in range(1, in_glr.shape[0] + 1) for j in
                     range(1, in_glr.shape[1] + 1)]) / Ns

    # Long Run Low Grey Level Emphasis
    lrlgle = np.sum([(in_glr[i - 1, j - 1] * (j ** 2)) / (i ** 2) for i in range(1, in_glr.shape[0] + 1) for j in
                     range(1, in_glr.shape[1] + 1)]) / Ns

    # Long Run High Grey Level Emphasis
    lrhgle = np.sum([in_glr[i - 1, j - 1] * (j ** 2) * (i ** 2) for i in range(1, in_glr.shape[0] + 1) for j in
                     range(1, in_glr.shape[1] + 1)]) / Ns

    # print(Ns)
    # Gray Level Non Uniforminty
    glnu = np.sum((ri ** 2)) / Ns

    # Gray Level Non Uniforminty Normalised
    glnun = np.sum((ri ** 2)) / Ns ** 2

    # Run Length Non Uniforminty
    rlnu = np.sum((rj ** 2)) / Ns

    # Run Length Non Uniforminty Normalised
    rlnun = np.sum((rj ** 2)) / Ns ** 2

    # Run Percentage
    rp = Ns / Nv

    # Gray Level Variance

    glv = np.sum([pij[i - 1, j - 1] * ((i - mui) ** 2) for i in range(1, pij.shape[0] + 1) for j in range(1, pij.shape[1] + 1)])

    # Run Length Variance
    rlv = np.sum([pij[i - 1, j - 1] * ((j - muj) ** 2) for i in range(1, pij.shape[0] + 1) for j in range(1, pij.shape[1] + 1)])

    # Run Entropy
    re = -np.sum([pij[i-1, j-1] * np.log2(pij[i-1, j-1]) for i in range(0, pij.shape[0] + 1) for j in range(0, pij.shape[1] + 1) if pij[i-1, j-1] > 0])

    out_props = [sre, lre, lgle, hgle, srlgle, srhgle, lrlgle, lrhgle, glnu, glnun, rlnu, rlnun, rp, glv, rlv, re]

    return out_props

def get_glrlm_lbl():
    out_lbl = [
        'ShortRunEmphasis',
        'LongRunEmphasis',
        'LowGreyLevelEmphasis',
        'HighGreyLevelEmphasis',
        'ShortRunLowGreyLevelEmphasis',
        'ShortRunHighGreyLevelEmphasis',
        'LongRunLowGreyLevelEmphasis',
        'LongRunHighGreyLevelEmphasis',
        'GrayLevelNonUniforminty',
        'GrayLevelNonUniformintyNormalised',
        'RunLengthNonUniforminty',
        'RunLengthNonUniformintyNormalised',
        'RunPercentage',
        'GrayLevelVariance',
        'RunLengthVariance',
        'RunEntropy'
    ]
    return out_lbl


def runs_of_ones_list(bits):
    return [sum(g) for b, g in itertools.groupby(bits) if b]


def get_glrlms(in_img):
    rows, cols = np.indices(in_img.shape)

    max_poss_run = np.max([np.shape(in_img)[0], np.shape(in_img)[1], len(in_img.diagonal())])

    # For 0 Degrees
    glr0 = np.zeros((in_img.max(), max_poss_run), dtype=np.int8)

    for int_lvl in range(1, in_img.max() + 1):
        runs_list = []
        for r in in_img:
            runs_list.append(runs_of_ones_list(r == int_lvl))

        col_idxs = [g - 1 for r in runs_list for g in r]
        for a in col_idxs:
            glr0[int_lvl - 1, a] += 1
    # print('0 Degrees')
    # print(glr0)

    glr90 = np.zeros((in_img.max(), max_poss_run), dtype=np.int8)
    for int_lvl in range(1, in_img.max() + 1):
        # print(int_lvl)
        runs_list = []
        for r in in_img.T:
            # print(r)
            runs_list.append(runs_of_ones_list(r == int_lvl))

        col_idxs = [g - 1 for r in runs_list for g in r]
        for a in col_idxs:
            glr90[int_lvl - 1, a] += 1
    # print('90 Degrees')
    # print(glr90)

    glr45 = np.zeros((in_img.max(), max_poss_run), dtype=np.int8)
    for int_lvl in range(1, in_img.max() + 1):
        # print(int_lvl)
        runs_list = []
        for diag_num in range(0, in_img.shape[0] + 1):
            row_vals = np.diag(rows, k=diag_num)
            col_vals = np.diag(cols, k=diag_num)
            r = np.fliplr(in_img)[row_vals, col_vals]
            # print(r)
            runs_list.append(runs_of_ones_list(r == int_lvl))

        for diag_num in range(-(in_img.shape[1] - 1), 0):
            row_vals = np.diag(rows, k=diag_num)
            col_vals = np.diag(cols, k=diag_num)
            r = np.fliplr(in_img)[row_vals, col_vals]
            # print(r)
            runs_list.append(runs_of_ones_list(r == int_lvl))
        # print(runs_list)
        col_idxs = [g - 1 for r in runs_list for g in r]
        for a in col_idxs:
            glr45[int_lvl - 1, a] += 1
    # print('45 Degrees')
    # print(glr45)

    glr135 = np.zeros((in_img.max(), max_poss_run), dtype=np.int8)
    for int_lvl in range(1, in_img.max() + 1):
        # print(int_lvl)
        runs_list = []
        for diag_num in range(0, in_img.shape[0] + 1):
            row_vals = np.diag(rows, k=diag_num)
            col_vals = np.diag(cols, k=diag_num)
            r = in_img[row_vals, col_vals]
            # print(r)
            runs_list.append(runs_of_ones_list(r == int_lvl))

        for diag_num in range(-(in_img.shape[1] - 1), 0):
            row_vals = np.diag(rows, k=diag_num)
            col_vals = np.diag(cols, k=diag_num)
            r = in_img[row_vals, col_vals]
            # print(r)
            runs_list.append(runs_of_ones_list(r == int_lvl))
        # print(runs_list)
        col_idxs = [g - 1 for r in runs_list for g in r]
        for a in col_idxs:
            glr135[int_lvl - 1, a] += 1

    # print('135 Degrees')
    # print(glr135)

    return glr0, glr45, glr90, glr135