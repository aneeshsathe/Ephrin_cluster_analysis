import numpy as np
import skimage


def an_get_glszm_props(rprop):
    in_img = rprop.intensity_image
    # print(np.max(in_img)+1)
    glszm = get_glszm(in_img)
    out_props, out_lbl = get_glszm_props(glszm, in_img)
    return out_props, out_lbl


def get_glszm(in_img):
    """
    Function to generate Gray Level Size Zone Matrix (GLSZM)
    """
    # Get zone sizes by intensity
    pro_mat = []
    for int_lvl in range(0, np.max(in_img) + 1):
        bw = skimage.measure.label(in_img == int_lvl)
        zone_area = [rprop.area for rprop in skimage.measure.regionprops(bw)]
        # print(zone_area)
        pro_mat.append(zone_area)

    max_zone_size = np.max([np.max(m) for m in pro_mat if m])
    # Generate GLSZM
    glszm = np.zeros(((np.max(in_img), max_zone_size)), dtype=np.int8)  # max(pro_mat)[0]
    # print(glszm.shape)
    for int_lvl, mat in enumerate(pro_mat):
        # print(mat)
        for m in mat:
            # print(m)
            glszm[int_lvl - 1, m - 1] += 1

    return glszm


def get_glszm_props(glszm, in_img):
    Ns = np.float64(np.sum(glszm))
    Nv = np.float64(np.size(in_img))
    si = np.float64(np.sum(glszm, axis=1))
    sj = np.float64(np.sum(glszm, axis=0))

    pij = glszm / Ns
    mug = np.sum([pij[i - 1, j - 1] * i for j in range(1, len(sj) + 1) for i in range(1, len(si) + 1)])
    muj = np.sum([pij[i - 1, j - 1] * j for j in range(1, len(sj) + 1) for i in range(1, len(si) + 1)])

    # Small Zone emphasis
    sze = np.sum(np.float32(sj) / [j ** 2 for j in range(1, len(sj) + 1)]) / Ns
    # Large Zone emphasis
    lze = np.sum(np.float32(sj) * [j ** 2 for j in range(1, len(sj) + 1)]) / Ns
    # Low grey level zone emphasis
    lglze = np.sum(np.float32(si) / [i ** 2 for i in range(1, len(si) + 1)]) / Ns
    # High grey level zone emphasis
    hglze = np.sum(np.float32(si) * [i ** 2 for i in range(1, len(si) + 1)]) / Ns

    # Small Zone Low grey level emphasis
    szlgle = np.sum([np.float32(glszm[i - 1, j - 1]) / (i ** 2) * (j ** 2) for j in range(1, len(sj) + 1) for i in
                     range(1, len(si) + 1)]) / Ns

    # Small Zone High grey level emphasis
    szhgle = np.sum([np.float32(glszm[i - 1, j - 1]) * (i ** 2) / (j ** 2) for j in range(1, len(sj) + 1) for i in
                     range(1, len(si) + 1)]) / Ns

    # Large Zone Low Grey Level Emphasis
    lzlgle = np.sum([np.float32(glszm[i - 1, j - 1]) * (j ** 2) / (i ** 2) for j in range(1, len(sj) + 1) for i in
                     range(1, len(si) + 1)]) / Ns

    # Large Zone High Grey Level Emphasis
    lzhgle = np.sum([np.float32(glszm[i - 1, j - 1]) * (j ** 2) * (i ** 2) for j in range(1, len(sj) + 1) for i in
                     range(1, len(si) + 1)]) / Ns

    # Gray Level Non Uniformity
    glnu = np.sum(si ** 2) / np.float32(Ns)

    # Gray Level Non Uniformity Normalised
    glnun = np.sum(si ** 2) / (np.float32(Ns) ** 2)

    # Zone Size Non Uniformity
    zsnu = np.sum(sj ** 2) / (np.float32(Ns))

    # Zone Size Non Uniformity Normalised
    zsnun = np.sum(sj ** 2) / (np.float32(Ns) ** 2)

    # Zone Percentage
    zp = Ns / Nv

    # Gray Level Variance
    glv = np.sum([np.float32(pij[i - 1, j - 1]) * ((i - mug) ** 2) for j in range(1, len(sj) + 1) for i in
                  range(1, len(si) + 1)])

    # Zone Size Variance
    zsv = np.sum([np.float32(pij[i - 1, j - 1]) * ((j - muj) ** 2) for j in range(1, len(sj) + 1) for i in
                  range(1, len(si) + 1)])

    # Zone Size Entropy
    zse = -np.sum(
        [pij[i - 1, j - 1] * np.log2(pij[i - 1, j - 1]) for j in range(1, len(sj) + 1) for i in range(1, len(si) + 1) if pij[i - 1, j - 1] > 0])

    out_props = [
        sze,
        lze,
        lglze,
        hglze,
        szlgle,
        szhgle,
        lzlgle,
        lzhgle,
        glnu,
        glnun,
        zsnu,
        zsnun,
        zp,
        glv,
        zsv,
        zse
    ]

    out_lbl = [
        'SmallZoneEmphasis',
        'LargeZoneEmphasis',
        'LowGreyLevelZoneEmphasis',
        'HighGreyLevelZoneEmphasis',
        'SmallZoneLowGreyLevelEmphasis',
        'SmallZoneHighGreyLevelEmphasis',
        'LargeZoneLowGreyLevelEmphasis',
        'LargeZoneHighGreyLevelEmphasis',
        'GrayLevelNonUniformity',
        'GrayLevelNonUniformityNormalised',
        'ZoneSizeNonUniformity',
        'ZoneSizeNonUniformityNormalised',
        'ZonePercentage',
        'GrayLevelVariance',
        'ZoneSizeVariance',
        'ZoneSizeEntropy'
    ]
    out_lbl = ['GLSZM' + a for a in out_lbl]
    return out_props, out_lbl
