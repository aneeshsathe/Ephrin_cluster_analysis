import numpy as np

def an_ngldm_props(rprop):
    in_img = rprop.intensity_image

    a = 0
    dist = 1

    pro_idxs = np.array(
        [[i, j] for j in range(-dist, dist + 1) for i in range(-dist, dist + 1) if not [i, j] == [0, 0]])
    int_lvls = range(np.min(in_img), np.max(in_img) + 1)

    pro_out_s = []
    for si_count, int_lvl in enumerate(int_lvls):
        # print('Int level'+str(int_lvl))
        rows, cols = np.where(in_img == int_lvl)

        out_s = []  # np.zeros(len(rows))
        for test_pix in range(len(rows)):
            idxs = [id + [rows[test_pix], cols[test_pix]] for id in pro_idxs]
            idxs = [i for i in idxs if all([0 <= i[0] < in_img.shape[0], 0 <= i[1] < in_img.shape[1]])]
            orows = [i[0] for i in idxs]
            ocols = [i[1] for i in idxs]

            no_of_dep_pix = np.sum(np.abs(int_lvl - in_img[orows, ocols]) <= a)
            out_s.append(no_of_dep_pix)
            # print(no_of_dep_pix)
        pro_out_s.append(out_s)

    max_dep = max([max(s) for s in pro_out_s if s])
    out_ngldm = np.zeros((np.int(np.max(in_img)), max_dep + 1), dtype=np.int8)

    for int_lvl, use_s in enumerate(pro_out_s):
        for s in use_s:
            out_ngldm[int_lvl - 1, s] += 1

    ngdlm = np.float64(out_ngldm)

    Ng, Nn = ngdlm.shape
    Ns = np.float64(np.sum(ngdlm))
    si = np.float64(np.sum(ngdlm, axis=1))
    sj = np.float64(np.sum(ngdlm, axis=0))
    i = np.array(range(1, len(si) + 1))
    j = np.array(range(1, len(sj) + 1))

    # Low Dependence Emphasis
    lde = np.sum(sj / (j ** 2)) / Ns

    # High Dependence Emphasis
    hde = np.sum(sj * (j ** 2)) / Ns

    # Low Grey level Count emphasis
    lglce = np.sum(si / (i ** 2)) / Ns

    # High Grey Level Count Emphasis
    hglce = np.sum(si * (i ** 2)) / Ns

    # Low Dependence Low Grey Level Emphasis
    ldlgle = np.sum([ngdlm[ii - 1, jj - 1] / ((ii ** 2) * (jj ** 2)) for ii in i for jj in j]) / Ns

    # Low Dependence High Grey Level Emphasis
    ldhgle = np.sum([(ngdlm[ii - 1, jj - 1] * (ii ** 2)) / (jj ** 2) for ii in i for jj in j]) / Ns

    # High Dependence Low Grey Level Emphasis
    hdlgle = np.sum([(ngdlm[ii - 1, jj - 1] * (jj ** 2)) / (i ** 2) for ii in i for jj in j]) / Ns

    # High Dependence High Grey Level Emphasis
    hdhgle = np.sum([(ngdlm[ii - 1, jj - 1] * (jj ** 2) * (i ** 2)) for ii in i for jj in j]) / Ns

    # Grey Level NonUniformity
    glnu = np.sum((si ** 2)) / Ns

    # Grey Level NonUniformity Normalised
    glnun = np.sum((si ** 2)) / (Ns ** 2)

    # Dependence Count NonUniformity
    dcnu = np.sum((sj ** 2)) / Ns

    # Dependence Count NonUniformity Normalised
    dcnun = np.sum((sj ** 2)) / (Ns ** 2)

    # Grey Level Variance
    pij = ngdlm / Ns
    mui = np.sum([pij[ii - 1, jj - 1] * ii for ii in i for jj in j])
    glv = np.sum([pij[ii - 1, jj - 1] * ((ii - mui) ** 2) for ii in i for jj in j])

    # Dependence Count Variance
    muj = np.sum([pij[ii - 1, jj - 1] * jj for ii in i for jj in j])
    dcv = np.sum([pij[ii - 1, jj - 1] * ((jj - muj) ** 2) for ii in i for jj in j])

    # Dependence Count Entropy
    dce = -np.sum([pij[ii - 1, jj - 1] * (np.log2(pij[ii - 1, jj - 1])) for ii in i for jj in j if pij[ii - 1, jj - 1] > 0])

    # Dependence Count Energy
    dcener = np.sum(pij ** 2)

    out_props = [
        lde,
        hde,
        lglce,
        hglce,

        ldlgle,
        hdlgle,
        hdhgle,

        glnu,
        glnun,

        dcnu,
        dcnun,

        glv,
        dcv,
        dce,
        dcener
    ]
    out_lbl = [
        'LongDependenceEmphasis',
        'HighDependenceEmphasis',
        'LowGreyLevelCountEmphasis',
        'HighGreyLevelCountEmphasis',

        'LowDependenceLowGreyLevelEmphasis',
        'HighDependenceLowGreyLevelEmphasis',
        'HighDependenceHighGreyLevelEmphasis',

        'GreyLevelNonUniformity',
        'GreyLevelNonUniformityNormalised',

        'DependenceCountNonUniformity',
        'DependenceCountNonUniformityNormalised',

        'GreyLevelVariance',
        'DependenceCountVariance',
        'DependenceCountEntropy',
        'DependenceCountEnergy'
    ]
    out_lbl = ['NGLDM' + a for a in out_lbl]
    return out_props, out_lbl