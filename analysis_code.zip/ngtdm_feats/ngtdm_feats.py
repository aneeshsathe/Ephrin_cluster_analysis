import numpy as np

def an_get_ngtdm_props(rprop):
    in_img = rprop.intensity_image

    dist = 1
    # W = ((2.0*dist +1)**2) -1
    pro_idxs = np.array([[i,j] for j in range(-dist, dist+1) for i in range(-dist, dist+1) if not [i, j] == [0,0]])

    int_lvls = range(np.min(in_img),np.max(in_img)+1)
    Ng = np.max(in_img)
    ni = np.zeros(len(int_lvls))
    pi = np.zeros(len(int_lvls))
    si = np.zeros(len(int_lvls))

    for si_count, int_lvl in enumerate(int_lvls):
        rows, cols = np.where(in_img == int_lvl)
        ni[si_count] = float(len(rows))
        out_s = np.zeros(len(rows))
        for test_pix in range(len(rows)):
            idxs = [id+[rows[test_pix], cols[test_pix]] for id in pro_idxs]
            idxs = [i for i in idxs if all([0 <= i[0] < in_img.shape[0], 0 <= i[1] < in_img.shape[1]])]
            orows = [i[0] for i in idxs]
            ocols = [i[1] for i in idxs]
            W = float(len(orows))
            out_s[test_pix] = np.abs(int_lvl - (np.sum(in_img[orows, ocols])/W))

        si[si_count] = np.sum(out_s)

    pi = ni/np.sum(ni)
    Ngp = np.sum(pi>0)
    Nv = np.sum(ni)
    # ngtdm = np.column_stack((ni, pi, si))
    # ngtdm
    # Coarseness
    out_coarseness = 1/np.sum(si*pi)

    # Contrast
    if Ngp == 1:
        out_contrast = 0
    else:
        out_contrast = ((np.sum([(pii*pij)*((i-j)**2) for i,pii in enumerate(pi) for j, pij in enumerate(pi)]))/(Ngp*(Ngp-1)))*(np.sum(si)/Nv)

    # Busyness
    if Ngp == 1:
        out_busyness = 0
    else:
        out_busyness = np.sum(pi[pi!=0]*si[pi != 0])/np.sum([np.abs((i*pii)-(j*pij)) for i,pii in enumerate(pi[pi != 0]) for j, pij in enumerate(pi[pi != 0])])

    # Complexity
    out_complexity = np.sum([(np.abs(i-j))*(((pii*si[i])+(pij*si[j]))/(pii+pij)) for i, pii in enumerate(pi[pi != 0]) for j, pij in enumerate(pi[pi != 0])])/Nv

    # Strength
    out_strength = np.sum([(pii+pij)*((i-j)**2) for i, pii in enumerate(pi[pi != 0]) for j, pij in enumerate(pi[pi!=0])])/np.sum(si)

    out_props = [out_coarseness, out_contrast, out_busyness, out_complexity, out_strength]
    out_lbl = ['Coarseness', 'Contrast', 'Busyness', 'Complexity', 'Strength']
    out_lbl = ['NGTDM' + a for a in out_lbl]
    return out_props, out_lbl
