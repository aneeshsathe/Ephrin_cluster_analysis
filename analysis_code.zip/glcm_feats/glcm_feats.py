"""
Functions to extract GLCM features
"""

import os
import pickle
import numpy as np
from skimage.feature import greycomatrix, greycoprops
from skimage import img_as_ubyte
import scipy


def an_get_glcm_props(rprop, sum_glcm=False, mean_props=False, all_glcm_props=False):
    in_dist = [1, 2]  # , 4, 8, 10]
    in_angles = [np.radians(a) for a in [0, 45, 90, 135]]
    glcm = greycomatrix(img_as_ubyte(rprop.intensity_image), in_dist, in_angles, levels=256, symmetric=True, normed=True)

    pro_col_names = an_glcm_out_lbl()
    col_names = ['Dist' + str(d) + c for d in in_dist for c in pro_col_names]

    if all_glcm_props:
        glcm_props = np.array(
            [an_glcm_props(glcm[:, :, i, j]) for i in range(glcm.shape[-2]) for j in range(glcm.shape[-1])])
        return glcm_props, col_names

    elif mean_props:
        # Mean of Features of different GLCMS
        glcm_props_dist = np.array(
            [np.array([an_glcm_props(glcm[:, :, i, j]) for j in range(glcm.shape[-1])]) for i in range(glcm.shape[-2])])
        # print(glcm_props_dist.shape)
        # glcm_props_dist_mean = np.array([np.array(glcm_props_dist[i,:,0].mean()) for i in range(glcm_props_dist.shape[0])])
        # glcm_props_dist_mean = np.array([glcm_props_dist[i,:,0].mean() for i in range(glcm_props_dist.shape[0])])
        glcm_props_dist_mean = glcm_props_dist.mean(axis=1).ravel()
        # glcm_props_dist_mean.shape
        # print(glcm_props_dist_mean)
        return glcm_props_dist_mean, col_names

    elif sum_glcm:
        # Features of Sum GLCM
        glcm_sum = np.sum(glcm, axis=3)
        mean_glcm_props = np.array([np.array([an_glcm_props(glcm_sum[:, :, i]) for i in range(glcm_sum.shape[-1])])])
        return mean_glcm_props.ravel(), col_names

def an_glcm_props(in_glcm):
    g_props = ['homogeneity', 'energy', 'correlation']  # 'contrast', 'dissimilarity', , 'ASM'

    g_feats = np.array(
        [greycoprops(in_glcm.reshape(in_glcm.shape[0], in_glcm.shape[1], 1, 1), prop=p) for p in g_props]).ravel()

    joint_max = np.max(in_glcm)
    joint_avg = np.sum([i * in_glcm[i, j] for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1])])
    joint_var = np.sum(
        [((i - joint_avg) ** 2) * in_glcm[i, j] for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1])])
    joint_ent = np.sum(
        in_glcm.ravel() * [np.log2(x) if not x == 0 else np.finfo(float).eps for x in in_glcm.ravel()])

    pi, pj, p_i_plus_j, p_i_minus_j, k_minus, k_plus = an_diag_prob(in_glcm)

    diff_avg = np.sum(k_minus * p_i_minus_j)
    diff_var = np.sum(((k_minus - diff_avg) ** 2) * (p_i_minus_j))
    diff_entropy = np.sum(p_i_minus_j * [np.log2(x) if not x == 0 else np.finfo(float).eps for x in p_i_minus_j])

    sum_avg = np.sum(k_plus * p_i_plus_j)
    sum_var = np.sum(((k_plus - sum_avg) ** 2) * (p_i_plus_j))
    sum_entropy = np.sum(p_i_plus_j * [np.log2(x) if not x == 0 else np.finfo(float).eps for x in p_i_plus_j])

    ang_sec_moment = np.sum(
        [in_glcm[i, j] ** 2 for i in range(1, in_glcm.shape[0]) for j in range(1, in_glcm.shape[1])])
    glcm_contrast = np.sum(
        [((i - j) ** 2) * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in range(1, in_glcm.shape[1])])
    glcm_dissm = np.sum(
        [(np.abs(i - j)) * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in range(1, in_glcm.shape[1])])

    glcm_inv_diff = np.sum([in_glcm[i, j] / (1 + (np.abs(i - j))) for i in range(1, in_glcm.shape[0]) for j in
                            range(1, in_glcm.shape[1])])
    glcm_inv_diff_norm = np.sum(
        [in_glcm[i, j] / (1 + ((np.abs(i - j)) / in_glcm.shape[0])) for i in range(1, in_glcm.shape[0]) for j in
         range(1, in_glcm.shape[1])])
    glcm_inv_diff_moment = np.sum([in_glcm[i, j] / (1 + ((i - j) ** 2)) for i in range(1, in_glcm.shape[0]) for j in
                                   range(1, in_glcm.shape[1])])
    glcm_inv_diff_moment_norm = np.sum(
        [in_glcm[i, j] / (1 + (((i - j) ** 2) / (in_glcm.shape[0] ** 2))) for i in range(1, in_glcm.shape[0]) for j
         in range(1, in_glcm.shape[1])])

    glcm_inv_var = 2 * np.sum(
        [in_glcm[i, j] / ((i - j) ** 2) if j > i else 0 for i in range(in_glcm.shape[0]) for j in
         range(in_glcm.shape[1])])

    glcm_autocorr = np.sum(
        [i * j * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in range(1, in_glcm.shape[1])])

    glcm_cluster_tendency = np.sum(
        [((i + j - (2 * pi.mean())) ** 2) * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in
         range(1, in_glcm.shape[1])])
    glcm_cluster_shade = np.sum(
        [((i + j - (2 * pi.mean())) ** 3) * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in
         range(1, in_glcm.shape[1])])
    glcm_cluster_promi = np.sum(
        [((i + j - (2 * pi.mean())) ** 4) * in_glcm[i, j] for i in range(1, in_glcm.shape[0]) for j in
         range(1, in_glcm.shape[1])])

    HXY = scipy.stats.entropy(in_glcm[in_glcm > 0])
    HX = scipy.stats.entropy(pi)
    HXY1 = 0
    HXY2 = 0
    for i in range(in_glcm.shape[0]):
        for j in range(in_glcm.shape[1]):
            pixpj = pi[i] * pj[j]
            if pixpj > 0:
                a = pixpj
            else:
                a = np.finfo(float).eps
            HXY1 += in_glcm[i, j] * np.log2(a)
            HXY2 += a * np.log2(a)
    # HXY1 = -np.sum([(in_glcm[i,j])*(np.log2(pi[i]*pj[j])) for i in range(1,in_glcm.shape[0]) for j in range(1,in_glcm.shape[1])])
    # HXY2 = -np.sum([(pi[i]*pj[j])*(np.log2(pi[i]*pj[j])) for i in range(1,in_glcm.shape[0]) for j in range(1,in_glcm.shape[1])])

    meas_info_corr1 = (HXY - HXY1) / HX

    if HXY > HXY2:
        meas_info_corr2 = 0
    else:
        meas_info_corr2 = np.sqrt(1 - (np.exp(-2 * (HXY2 - HXY))))

    out_props = [
        joint_max,
        joint_avg,
        joint_var,
        joint_ent,
        diff_avg,
        diff_var,
        diff_entropy,
        sum_avg,
        sum_var,
        sum_entropy,
        ang_sec_moment,
        glcm_contrast,
        glcm_dissm,
        g_feats[0],
        g_feats[1],
        g_feats[2],
        glcm_inv_diff,
        glcm_inv_diff_norm,
        glcm_inv_diff_moment,
        glcm_inv_diff_moment_norm,
        glcm_inv_var,
        glcm_autocorr,
        glcm_cluster_tendency,
        glcm_cluster_shade,
        glcm_cluster_promi,
        meas_info_corr1,
        meas_info_corr2
    ]

    return np.array(out_props)

def an_glcm_out_lbl():
    out_lbl = [
        'GLCMJointMax',
        'GLCMJointAvg',
        'GLCMJointVar',
        'GLCMJointEntropy',
        'GLCMDiffAvg',
        'GLCMDiffVar',
        'GLCMDiffEntropy',
        'GLCMSumAvg',
        'GLCMSumVar',
        'GLCMSumEntropy',
        'GLCMAngSecMoment',
        'GLCMContrast',
        'GLCMDissim',
        'GLCMHomogeneity',
        'GLCMEnergy',
        'GLCMCorrelation',
        'GLCMInvDiff',
        'GLCMInvDiffNorm',
        'GLCMInvDiffMoment',
        'GLCMInvDiffMomentNorm',
        'GLCMInvVar',
        'GLCMAutoCorr',
        'GLCMClustTend',
        'GLCMClustShade',
        'GLCMClustPromi',
        'GLCMMeasInfoCorr1',
        'GLCMMeasInfoCorr2'

    ]
    return out_lbl


# def an_diag_prob(in_glcm):
#     pi = np.sum(in_glcm, axis=0)
#     pj = np.sum(in_glcm, axis=1)
#     k_minus = range(0, in_glcm.shape[0])
#     k_plus = range(2, 2*in_glcm.shape[0])
#     p_i_plus_j = np.zeros(len(k_plus))
#     p_i_minus_j = np.zeros(len(k_minus))
#     for ii, k in enumerate(k_plus):
#         p_i_plus_j[ii]=np.sum([in_glcm[i,j] if not k-(i+j) else 0 for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1])])

#     for ii, k in enumerate(k_minus):
#         p_i_minus_j[ii]=np.sum([in_glcm[i,j] if not k-np.abs(i-j) else 0 for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1])])

#     return pi, pj, p_i_plus_j, p_i_minus_j, k_minus, k_plus

def an_diag_prob(in_glcm):
    pi = np.sum(in_glcm, axis=0)
    pj = np.sum(in_glcm, axis=1)

    k_minus = range(0, in_glcm.shape[0])
    k_plus = range(2, 2 * in_glcm.shape[0])

    if os.path.isfile('/media/data/Andrea/analysis_code/glcm_feats/GLCM_vars.pickle'):
        with open('/media/data/Andrea/analysis_code/glcm_feats/GLCM_vars.pickle') as f:
            p_i_plus_j_idxs, p_i_minus_j_idxs = pickle.load(f)
    else:

        p_i_plus_j_idxs = []
        for ii, k in enumerate(k_plus):
            p_i_plus_j_idxs.append(
                [(i, j) for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1]) if not k - (i + j)])

        p_i_minus_j_idxs = []
        for ii, k in enumerate(k_minus):
            p_i_minus_j_idxs.append(
                [(i, j) for i in range(in_glcm.shape[0]) for j in range(in_glcm.shape[1]) if not k - np.abs(i - j)])

        with open('/media/data/Andrea/analysis_code/glcm_feats/GLCM_vars.pickle', 'w') as f:
            pickle.dump([p_i_plus_j_idxs, p_i_minus_j_idxs], f, protocol=-1)

    p_i_plus_j = np.array([np.sum(in_glcm[zip(*a1)]) for a1 in p_i_plus_j_idxs])
    p_i_minus_j = np.array([np.sum(in_glcm[zip(*a1)]) for a1 in p_i_minus_j_idxs])

    return pi, pj, p_i_plus_j, p_i_minus_j, k_minus, k_plus

